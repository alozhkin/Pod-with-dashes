#import <Foundation/Foundation.h>

NSString* podspecWithFilesExample(void);
